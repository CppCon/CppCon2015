# we're presuming the existence of the g++ and/or clang++ compiler
# running on a bash/bashlike shell.  This works well on BSD unix (MacOS) as
# well as cygwin under windows. I chose this as it is the simplest/universal
# platform for compiling and running our examples.

# to "install this"
# create a sand box directory in a convenient place
# run the shell command:
# . <path to this directory>/setup.sh

# Copy the demo files to your sand box directory ($PWD)
cp ../example/* .

# This should setup up the environmental variable which gcc requires to
# include your own copy of the boost libraries.
export CPLUS_INCLUDE_PATH=/cygdrive/c/boost_1_43_0
export PATH=.:$PATH

e() {
	"/cygdrive/c/Program Files/Windows NT/Accessories/wordpad.exe" $1
}

d() {
	printf "\033c"
	nl -ba $1
}

# now you should be able to display, compile and run each example in turn.
