// simple program for calculating velocity = length / time

// include headers to implement output operations for quantities with units
#include <iostream>
#include <boost/units/io.hpp>

// include just the SI units we're using here
#include <boost/units/systems/si/time.hpp>
#include <boost/units/systems/si/length.hpp>
#include <boost/units/systems/si/velocity.hpp>

#include <boost/units/quantity.hpp>

// specify namespace to enhance readability
using namespace boost::units;

// define unit quantities in the global namespace

#include <boost/units/base_units/si/meter.hpp>
typedef si::meter_base_unit::unit_type meter_unit;
BOOST_UNITS_STATIC_CONSTANT(meters, meter_unit);
BOOST_UNITS_STATIC_CONSTANT(meter, meter_unit);

#include <boost/units/base_units/si/second.hpp>
typedef si::second_base_unit::unit_type second_unit;
BOOST_UNITS_STATIC_CONSTANT(seconds, second_unit);
BOOST_UNITS_STATIC_CONSTANT(second, second_unit);

// create types in our or own namespace in order to make the code
// idiot proof to write, debug and verify.  Note that this totally
// hides our units library from user code - think about naming
// and/or whether or not you really want to do this.

// define alternative units into the global namespace
typedef quantity<si::length, float> length; 
typedef quantity<si::time, float> elapsed_time;
typedef quantity<si::velocity, float> velocity;

int main(){
    elapsed_time et = 2.7f * seconds;
    length l = 35.0f * meters;
    velocity v; // velocity in meters / second !
    v = l / et;  // works great!

    std::cout << v << " = " << l << " / " << et << '\n';;
    return 0;
}
