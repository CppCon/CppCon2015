// simple program for calculating velocity = length / time
// trivial error in units IS detected

#include <iostream>

// include all SI units
//#include <boost/units/systems/si.hpp>

// include just the SI units we're using here
#include <boost/units/systems/si/time.hpp>
#include <boost/units/systems/si/length.hpp>
#include <boost/units/systems/si/velocity.hpp>

#include <boost/units/io.hpp>
#include <boost/units/quantity.hpp>

int main(){
    boost::units::quantity<boost::units::si::time, float> et; // always in seconds
    boost::units::quantity<boost::units::si::length, float> l; // always in meters
    boost::units::quantity<boost::units::si::velocity, float> v; // velocity in meters / second !
    v = l / et;  // works great!
    //v = l * et;  // but this invokes compile error when trying to assign to velocity
    std::cout << v << " = " << l << " / " << et << '\n';
    return 0;
}
