// simple program for calculating velocity = length / time

#include <iostream>

// Problem: How do we initialize a quantity?

// include just the SI units we're using here
#include <boost/units/systems/si/time.hpp>
#include <boost/units/systems/si/length.hpp>
#include <boost/units/systems/si/velocity.hpp>

#include <boost/units/io.hpp>
#include <boost/units/quantity.hpp>

int main(){
    // damn! how do I initialize this?
    boost::units::quantity<boost::units::si::time, float> et(2.7); 
    // same here?
    boost::units::quantity<boost::units::si::length, float> l = 35.0f;
    // velocity in meters / second !
    boost::units::quantity<boost::units::si::velocity, float> v; 
    v = l / et;  // works great!
    std::cout << v << " = " << l << " / " << et << '\n';
    return 0;
}
