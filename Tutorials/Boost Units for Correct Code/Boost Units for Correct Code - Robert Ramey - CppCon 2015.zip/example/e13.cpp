// include headers to implement output operations for quantities with units
#include <iostream>
#include <boost/units/io.hpp>

// incorporate all our other units/quantities
#include "e12.hpp"

#include <boost/units/base_units/metric/liter.hpp>
typedef boost::units::metric::liter_base_unit::unit_type liter_unit;
typedef boost::units::quantity<liter_unit, float> volume_in_liters;
BOOST_UNITS_STATIC_CONSTANT(liter, liter_unit);    
BOOST_UNITS_STATIC_CONSTANT(liters, liter_unit);

#include <boost/units/base_units/us/gallon.hpp>
typedef boost::units::us::gallon_base_unit::unit_type gallon_unit;
typedef boost::units::quantity<gallon_unit, float> volume_in_gallons;
BOOST_UNITS_STATIC_CONSTANT(gallon, gallon_unit);    
BOOST_UNITS_STATIC_CONSTANT(gallons, gallon_unit);

int main(){
    elapsed_time et = 2.7f * seconds;

    // "base" units of volume are cubic meters - so the following is OK
    volume v1 = 2.7f * cubic_meters;

    // but the following is NOT OK
    // volume v2 = 1000.0f * liters;

    // but the following IS OK.  
    volume v3 = static_cast<volume>(1000.0f * liters); // works !

    // is the intrinsic unit of measure in the SI system.
    volume fuel_capacity = static_cast<volume>(2.5f * gallons);

    // does calculation in basic metric units
    consumption_rate burn_rate = fuel_capacity / et;

    std::cout << burn_rate << " = " << fuel_capacity << " / " << et << '\n';;
    return 0;
}
