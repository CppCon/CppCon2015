// simple program for calculating velocity = length / time
// trivial typographic error is detected

#include <iostream>

// base dimensions
struct elapsed_time {
    float m_value;
    elapsed_time(float et = 0) : m_value(et) {}
};
std::ostream & operator<<(std::ostream & os, const elapsed_time & et){
    os << et.m_value;
}
    
struct length {
    float m_value;
    length(float l = 0) : m_value(l) {}
};
std::ostream & operator<<(std::ostream & os, const length & l){
    os << l.m_value;
}

// derived dimension // l^1 * et^(-1)
struct velocity {
    //use default assign, copy, etc.
    float m_value;
    velocity(float v = 0) : m_value(v) {}
};
std::ostream & operator<<(std::ostream & os, const velocity & v){
    os << v.m_value;
}

// legal operation
velocity operator/(length const & l, elapsed_time const & t){
    return l.m_value / t.m_value;
}

int main(){
    elapsed_time et(2.7f);
    length l(35.0f);
    velocity v;
    //v = l * et; // compile time error!
    v = l / et; // but still works!
    std::cout << v << " = " << l << " / " << et << '\n';
    return 0;
}
