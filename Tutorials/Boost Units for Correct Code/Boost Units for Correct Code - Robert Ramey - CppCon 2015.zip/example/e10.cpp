// simple program for calculating velocity = length / time

// include headers to implement output operations for quantities with units
#include <iostream>
#include <boost/units/io.hpp>

#include "e9.hpp"

int main(){
    elapsed_time et = 2.7f * seconds;
    length l = 35.0f * meters;
    velocity v; // velocity in meters / second !
    v = l / et;  // works great!

    std::cout << v << " = " << l << " / " << et << '\n';;
    return 0;
}
