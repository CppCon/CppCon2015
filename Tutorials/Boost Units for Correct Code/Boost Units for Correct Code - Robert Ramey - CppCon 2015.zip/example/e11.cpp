// simple program for calculating velocity = length / time

// include headers to implement output operations for quantities with units
#include <iostream>
#include <boost/units/io.hpp>

// include headers to implement output operations for quantities with units
#include <iostream>
#include <boost/units/io.hpp>

#include "e9.hpp"

using namespace boost::units;

#include <boost/units/base_units/us/foot.hpp>

typedef boost::units::us::foot_base_unit::unit_type foot_unit;
BOOST_UNITS_STATIC_CONSTANT(feet, foot_unit);
BOOST_UNITS_STATIC_CONSTANT(foot, foot_unit);

int main(){
;
    elapsed_time et = 2.7f * seconds;

    //length l = 105.0 * feet; // fails to compile !!!
    length l = static_cast<length>(105.0 * feet); // works !!!

    velocity v; // velocity in meters / second !
    v = l / et;  // works great!

    std::cout << v << " = " << l << " / " << et << '\n';

    std::cout 
        << v << " = " 
        << static_cast<quantity<foot_unit> >(l) << " / "
        << et << '\n'
    ;

    return 0;
}
