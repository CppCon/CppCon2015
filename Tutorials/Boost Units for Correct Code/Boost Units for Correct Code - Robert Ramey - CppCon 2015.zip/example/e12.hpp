#ifndef E12_INCLUDE
#define E12_INCLUDE

// incorporate all our other units/quantities
#include "e9.hpp"

// add volume quantities
#include <boost/units/systems/si/volume.hpp>

// bring volume quantity into the current namespace
typedef boost::units::quantity<boost::units::si::volume, float> volume;
BOOST_UNITS_STATIC_CONSTANT(cubic_meter, boost::units::si::volume);
BOOST_UNITS_STATIC_CONSTANT(cubic_meters, boost::units::si::volume);

// derive special units that we use in our application

// derived dimension for consumption_rate : L^3 T^-1
typedef boost::units::derived_dimension<
    boost::units::length_base_dimension,3,
    boost::units::time_base_dimension,-1
>::type consumption_rate_dimension;                

typedef boost::units::unit<
    consumption_rate_dimension,
    boost::units::si::system
> consumption_rate_unit;
typedef boost::units::quantity<consumption_rate_unit, float> consumption_rate;

BOOST_UNITS_STATIC_CONSTANT(cubic_meters_per_second, consumption_rate);

#endif // E12_INCLUDE
