// simple program for calculating velocity = length / time

#include <iostream>
// Problem: How do we initialize a quantity?

// include just the SI units we're using here
#include <boost/units/systems/si/time.hpp>
#include <boost/units/systems/si/length.hpp>
#include <boost/units/systems/si/velocity.hpp>

#include <boost/units/io.hpp>
#include <boost/units/quantity.hpp>

// One Solution: Use static member function
// quanity<units, value_type>::from_value(value_type v);
 
int main(){
    // specify namespace to enhance readability
    using namespace boost::units;

    quantity<si::time, float> et = quantity<si::time, float>::from_value(2.7f);
    // what unit is 35.0 in?
    quantity<si::length, float> l = quantity<si::length, float>::from_value(35.0f); 
    quantity<si::velocity, float> v; // velocity in meters / second !
    v = l / et;  // works great!

    // notice that output includes names of units - for free!
    std::cout << v << " = " << l << " / " << et << '\n';
    return 0;
}

// new problem - ugly, error prone, non-transparent
