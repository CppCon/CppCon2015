// simple program for calculating velocity = length / time
// trivial typographic error undetected
#include <iostream>
int main(){
    float et = 2.7f; // elapsed time
    float l = 35.0f; // length
    float v; // velocity
    v = l * et; // undetected error!
    std::cout << v << " = " << l << " / " << et << '\n';
    return 0;
}
