# we're presuming the existence of the g++ and/or clang++ compiler
# running on a bash/bashlike shell.  This works well on BSD unix (MacOS) as
# well as cygwin under windows. I chose this as it is the simplest/universal
# platform for compiling and running our examples.

# to "install this"
# create a sandbox directory in a convenient place
# cd to this new sandbox directory
# run the shell command:
# . <path to this example directory>/setup.sh

# this should setup up the environmental variable which gcc requires to
# and copy the demo files to your sand box directory ($PWD)
cp ../example/* .

# include your own copy of the boost libraries.
export CPLUS_INCLUDE_PATH=/Users/robertramey/WorkingProjects/modular-boost
export PATH=.:$PATH

e() {
	nano $1
}

d() {
	printf "\033c" # clear screen
	nl -ba $1
}

# now you should be able to display, compile and run each example in turn.
