// include headers to implement output operations for quantities with units
#include <iostream>
#include <boost/units/io.hpp>
#include <boost/units/conversion.hpp>
#include <boost/units/static_constant.hpp>
#include <boost/units/systems/si/mass.hpp>

// incorporate all our other units/quantities
#include "e12.hpp"

#include <boost/units/base_units/us/pound.hpp>
typedef boost::units::us::pound_base_unit::unit_type pound_unit;
typedef boost::units::quantity<pound_unit, float> weight_in_pounds;
BOOST_UNITS_STATIC_CONSTANT(pound, pound_unit);    
BOOST_UNITS_STATIC_CONSTANT(pounds, pound_unit);

BOOST_UNITS_DEFINE_CONVERSION_FACTOR(pound_unit, boost::units::si::mass, float, 2.2f);

#include <boost/units/base_units/metric/minute.hpp>
typedef boost::units::metric::minute_base_unit::unit_type minute_unit;
typedef boost::units::quantity<minute_unit, float> time_in_minutes;
BOOST_UNITS_STATIC_CONSTANT(minute, minute_unit);    
BOOST_UNITS_STATIC_CONSTANT(minutes, minute_unit);

#include <boost/units/base_units/us/gallon.hpp>
typedef boost::units::us::gallon_base_unit::unit_type gallon_unit;
typedef boost::units::quantity<gallon_unit, float> volume_in_gallons;
BOOST_UNITS_STATIC_CONSTANT(gallon, gallon_unit);    
BOOST_UNITS_STATIC_CONSTANT(gallons, gallon_unit);

typedef boost::units::derived_dimension<
    boost::units::mass_base_dimension,1,
    boost::units::time_base_dimension,-1
>::type us_consumption_rate_dimension;

typedef boost::units::make_system<
    boost::units::us::pound_base_unit,
    boost::units::metric::minute_base_unit
>::type us_system;                

typedef boost::units::unit<
    us_consumption_rate_dimension,
    us_system
> us_consumption_rate_unit;

typedef boost::units::quantity<us_consumption_rate_unit, float> us_consumption_rate;

namespace boost { namespace units {
template<> struct base_unit_info<us_consumption_rate_unit>
{
    static std::string name()               { return "pounds per minute"; }
    static std::string symbol()             { return "ppm"; }
};
}}

// make special arrangements to convert cubic meters / second of jet fuel
// to pounds / minute of jet fuel.
// Assuming A1 Jet Fuel http://en.wikipedia.org/wiki/Jet_fuel
// for magic constant to convert gallons of jet fuel to pounds
// 6.17 pounds / gallon

weight_in_pounds convert(const volume & m){
    return m *
        6.17f * pounds / gallon
        * 264.17f * gallons / cubic_meter
    ;
}

us_consumption_rate us_convert(const consumption_rate & cr){
    return cr
        * 6.17f * pounds / gallon
        * 264.17f * gallons / cubic_meter
        * 60.0f * seconds / minute
    ;
}

consumption_rate convert(const us_consumption_rate & us_cr){
    return us_cr / (
        6.17f * pounds / gallon
        * 264.17f * gallons / cubic_meter
        * 60.0f * seconds / minute
    );
}

int main(){
    elapsed_time et = 2.7f * seconds;
    volume fuel_capacity = static_cast<volume>(2376.0f * gallons);
    consumption_rate burn_rate = fuel_capacity / et;

    std::cout << burn_rate << " = " << fuel_capacity << " / " << et << '\n';    

    std::cout 
        << us_convert(burn_rate) << " = " 
        << convert(fuel_capacity) << " / " 
        << static_cast<time_in_minutes >(et)
        << '\n';

    return 0;
}
