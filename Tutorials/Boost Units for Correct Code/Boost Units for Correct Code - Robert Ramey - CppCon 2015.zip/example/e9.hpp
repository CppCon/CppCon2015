// include just the SI units we're using here
#include <boost/units/systems/si/time.hpp>
#include <boost/units/systems/si/length.hpp>
#include <boost/units/systems/si/velocity.hpp>

#include <boost/units/quantity.hpp>

// define unit quantities in the global namespace

#include <boost/units/base_units/si/meter.hpp>
typedef boost::units::si::meter_base_unit::unit_type meter_unit;
BOOST_UNITS_STATIC_CONSTANT(meters, meter_unit);
BOOST_UNITS_STATIC_CONSTANT(meter, meter_unit);

#include <boost/units/base_units/si/second.hpp>
typedef boost::units::si::second_base_unit::unit_type second_unit;
BOOST_UNITS_STATIC_CONSTANT(seconds, second_unit);
BOOST_UNITS_STATIC_CONSTANT(second, second_unit);

// create types in our or own namespace in order to make the code
// idiot proof to write, debug and verify.  Note that this totally
// hides our units library from user code - think about naming
// and/or whether or not you really want to do this.

// define alternative units into the global namespace
typedef boost::units::quantity<boost::units::si::length, float> length; 
typedef boost::units::quantity<boost::units::si::time, float> elapsed_time;
typedef boost::units::quantity<boost::units::si::velocity, float> velocity;
