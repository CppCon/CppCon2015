// simple program for calculating velocity = length / time

// include headers to implement output operations for quantities with units
#include <iostream>
#include <boost/units/io.hpp>

// include just the SI units we're using here
#include <boost/units/systems/si/time.hpp>
#include <boost/units/systems/si/length.hpp>
#include <boost/units/systems/si/velocity.hpp>

#include <boost/units/quantity.hpp>

// specify namespace to enhance readability
using namespace boost::units;

// define unit quantities in the global namespace

#include <boost/units/base_units/si/meter.hpp>
typedef si::meter_base_unit::unit_type meter_unit;
BOOST_UNITS_STATIC_CONSTANT(meters, meter_unit);
BOOST_UNITS_STATIC_CONSTANT(meter, meter_unit);

#include <boost/units/base_units/si/second.hpp>
typedef si::second_base_unit::unit_type second_unit;
BOOST_UNITS_STATIC_CONSTANT(seconds, second_unit);
BOOST_UNITS_STATIC_CONSTANT(second, second_unit);

#include <boost/units/base_units/us/foot.hpp>
typedef us::foot_base_unit::unit_type foot_unit;
BOOST_UNITS_STATIC_CONSTANT(feet, foot_unit);
BOOST_UNITS_STATIC_CONSTANT(foot, foot_unit);

int main(){
    quantity<si::time, float> et = 2.7f * seconds;
    //quantity<si::length, float> lf = 35.0f * feet; // damn! conversion error !!!
    
    // but the following works as there is an EXPLICIT constructor for a quantity
    // which takes another quantity of the same dimensionality.
    quantity<si::length, float> l = static_cast<quantity<si::length, float> >(113.75f * feet); // Works!
    quantity<si::velocity, float> v; // velocity in meters / second !
    v = l / et;  // works great!

    std::cout << v << " = " << l << " / " << et << '\n';
    return 0;
}
