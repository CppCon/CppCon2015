// simple program for calculating velocity = length / time

// include headers to implement output operations for quantities with units
#include <iostream>
#include <boost/units/io.hpp>

// include just the SI units we're using here
#include <boost/units/systems/si/time.hpp>
#include <boost/units/systems/si/length.hpp>
#include <boost/units/systems/si/velocity.hpp>

#include <boost/units/quantity.hpp>

/*
// turns out that the library defines operators for scalar * unit
// which returns a quanity<unit, typeof(scalar)).  Similar to the following

namespace boost { namespace units {
    template<typename Value, typename Units>
    boost::units::quantity<
	Units, 
	ValueType
    > operator*(ValueType const & lhs, Units const & rhs);
} // units
} // boost

// and it also defines something like for the basic quantities
// static boost::units::si::length meters;
*/

// So we can use a much more aesthetically pleasing solution
int main(){

    using namespace boost::units;
    using namespace boost::units::si;

    // now we can write 35.0f * meters to get return quantity<length, float> 
    // with a value of 35.0
    std::cout << 35.0f * meters << std::endl;

    quantity<si::time, float> et = 2.7f * seconds;   // always in seconds
    quantity<si::length, float> l = 35.0f * meters; // always in meters
    quantity<si::velocity, float> v; // velocity in meters / second !
    v = l / et;  // works great!

    std::cout << v << " = " << l << " / " << et << '\n';
    return 0;
}
