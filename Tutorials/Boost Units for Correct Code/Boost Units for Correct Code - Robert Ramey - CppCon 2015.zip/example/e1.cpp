// simple program for calculating velocity = length / time
#include <iostream>
int main(){
    float et = 2.7f; // elapsed time
    float l = 35.0f; // length
    float v; // velocity
    v = l / et;
    std::cout << v << " = " << l << " / " << et << '\n';
    return 0;
}
